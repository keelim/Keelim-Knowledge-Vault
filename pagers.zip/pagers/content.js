document.addEventListener('keydown', function(event) {
  let url = new URL(window.location.href);
  let page = url.searchParams.get('page'); // 'page' 매개변수 값 가져오기

  if (page === null) {
    page = 1; // page 매개변수가 없을 경우 1로 초기화
  } else {
    page = parseInt(page);
  }

  if (event.key === '<' || event.key === 'ArrowLeft') {
    if (page > 1) { // 페이지가 1보다 클 경우에만 감소
      page -= 1;
    }
  } else if (event.key === '>' || event.key === 'ArrowRight') {
    page += 1;
  }

  url.searchParams.set('page', page); // 변경된 'page' 값 설정
  window.location.href = url.href; // URL 변경
});
